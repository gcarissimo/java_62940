package com.coderhouse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase08Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase08Application.class, args);
	}

}
